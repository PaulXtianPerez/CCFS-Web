<?php include 'database.php'; ?>
<?php 
	if(isset($_POST['submit'])){
		
		

		
		$query = "INSERT INTO `schoolyear`(yearstart, yearend, totalAtt, totalSec, dateStart, dateEnd, pretui1, premisc1, prebook1, pretui2, premisc2, prebook2, gradetui1, grademisc1, gradebook1, gradetui2, grademisc2, gradebook2, gradetui3, grademisc3, gradebook3, gradetui4, grademisc4, gradebook4, gradetui5, grademisc5, gradebook5,gradetui6, grademisc6, gradebook6, scfee ) values ('$_POST[yearstart]', '$_POST[yearend]', '$_POST[totalAtt]', '$_POST[totalSec]', '$_POST[dateStart]', '$_POST[dateEnd]', '$_POST[pretui1]', '$_POST[premisc1]', '$_POST[prebook1]','$_POST[pretui2]', '$_POST[premisc2]', '$_POST[prebook2]', '$_POST[gradetui1]', '$_POST[grademisc1]', '$_POST[gradebook1]', '$_POST[gradetui2]', '$_POST[grademisc2]', '$_POST[gradebook2]', '$_POST[gradetui3]', '$_POST[grademisc3]', '$_POST[gradebook3]', '$_POST[gradetui4]', '$_POST[grademisc4]', '$_POST[gradebook4]', '$_POST[gradetui5]', '$_POST[grademisc5]', '$_POST[gradebook5]', '$_POST[gradetui6]', '$_POST[grademisc6]', '$_POST[gradebook6]', '$_POST[scfee]')";
		
		$insert_row = $mysqli->query($query) or die($mysqli->error.__LINE__);
		


	$message = 'School Year have been added';
	
	}
	
	
?>



<html>
<body>
	<header>

	</header>
	
<main>
	<h1> Add a SchoolYear</h1>
	<?php if(isset($message)){
			echo '<p>' .$message.'</p>';

	}else {}?>
	<form method="post" action="add.php">
		<p> 
			<label> Year Start:</label>
			<input type= "number" name ="yearstart" min = "0"/>
		</p>
		
		<p> 
			<label> Year End:</label>
			<input type= "number" name ="yearend" min = "0"/>
		</p>

			<p> 
			<label> Number of School Days:</label>
			<input type= "number" name ="totalAtt" min = "0"/>
		</p>

			

		<p> 
			<label> Total Section:</label>
			<input type= "number" name ="totalSec" min = "0"/>
		</p>

		<p> 
			<label> Date Start:</label>
			<input type= "date" name ="dateStart" min = "0"/>
		</p>

		<p> 
			<label> Date End:</label>
			<input type= "date" name ="dateEnd" min = "0"/>
		</p>

		<p><h3>PreSchool Fee</h3>

			<label> PreSchool 1 Tuition:</label>
			<input type= "number" name ="pretui1" min = "0"/>
		</p>

		<p>
			<label> PreSchool 1 Book:</label>
			<input type= "number" name ="prebook1" min = "0"/>
		</p>
		<p>
			<label> PreSchool 1 Misc:</label>
			<input type= "number" name ="premisc1" min = "0"/>
		</p>

			<label> PreSchool 2 Tuition:</label>
			<input type= "number" name ="pretui2" min = "0"/>
		</p>

		<p>
			<label> PreSchool 2 Book:</label>
			<input type= "number" name ="prebook2" min = "0"/>
		</p>
		<p>
			<label> PreSchool 2 Misc:</label>
			<input type= "number" name ="premisc2" min = "0"/>
		</p>

		<p><h3>GradeSchool Fee</h3>

			<label> Grade School 1 Tuition:</label>
			<input type= "number" name ="gradetui1" min = "0"/>
		</p>

		<p>
			<label> Grade School 1 Misc:</label>
			<input type= "number" name ="grademisc1" min = "0"/>
		</p>
		<p>
			<label> Grade School 1 Book:</label>
			<input type= "number" name ="gradebook1" min = "0"/>
		</p>

		
			<label> Grade School 2 Tuition:</label>
			<input type= "number" name ="gradetui2" min = "0"/>
		</p>

		<p>
			<label> Grade School 2 Misc:</label>
			<input type= "number" name ="grademisc2" min = "0"/>
		</p>
		<p>
			<label> Grade School 2 Book:</label>
			<input type= "number" name ="gradebook2" min = "0"/>
		</p>
		
			<label> Grade School 3 Tuition:</label>
			<input type= "number" name ="gradetui3" min = "0"/>
		</p>

		<p>
			<label> Grade School 3 Misc:</label>
			<input type= "number" name ="grademisc3" min = "0"/>
		</p>
		<p>
			<label> Grade School 3 Book:</label>
			<input type= "number" name ="gradebook3" min = "0"/>
		</p>
		
			<label> Grade School 4 Tuition:</label>
			<input type= "number" name ="gradetui4" min = "0"/>
		</p>

		<p>
			<label> Grade School 4 Misc:</label>
			<input type= "number" name ="grademisc4" min = "0"/>
		</p>
		<p>
			<label> Grade School 4 Book:</label>
			<input type= "number" name ="gradebook4" min = "0"/>
		</p>
		
			<label> Grade School 5 Tuition:</label>
			<input type= "number" name ="gradetui5" min = "0"/>
		</p>

		<p>
			<label> Grade School 5 Misc:</label>
			<input type= "number" name ="grademisc5" min = "0"/>
		</p>
		<p>
			<label> Grade School 5 Book:</label>
			<input type= "number" name ="gradebook5" min = "0"/>
		</p>

			<label> Grade School 6 Tuition:</label>
			<input type= "number" name ="gradetui6" min = "0"/>
		</p>

		<p>
			<label> Grade School 6 Misc:</label>
			<input type= "number" name ="grademisc6" min = "0"/>
		</p>
		<p>
			<label> Grade School 6 Book:</label>
			<input type= "number" name ="gradebook6" min = "0"/>
		</p>
		<p> 
			<label> Total Fee:</label>
			<input type= "number" name ="scfee" min = "0"/>
		</p>

		<p>
		<input type = "submit" name = "submit" value = "submit" "0"/>
		</p>

</main>

</body>
</html>

