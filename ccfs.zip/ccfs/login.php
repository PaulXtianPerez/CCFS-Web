<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <title>Login page</title>

 
  <body>

        
        <!-- Form start here -->
      <form method="post" class= "forms" action="login.php">
        <?php include('errors.php'); ?>
          <h1>User Login</h1>
          <br>
          <!-- Input Username -->
          <div class="form-group">
              <input type = "text" name="username" class="form-control" placeholder ="user name"/>
          </div>
          <!-- Input Password -->
          <div class="form-group">
            <input type = "password" name="password" class="form-control" placeholder ="password"/>
          </div>             
 
            <input type= "submit" class="btn btn-primary btn-block" name="login_user" value="login">
    
    </div>   
        </form>

      
  </body>
</html>