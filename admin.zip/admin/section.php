<?php include 'database.php'; ?>
<?php 
	if(isset($_POST['submit'])){
		
		

		
		$query = "INSERT INTO `section`(sename, gradelvl, adviserlname, yearid) values ('$_POST[sename]', '$_POST[gradelvl]', '$_POST[adviserlname]', '$_POST[yearid]')";
		
		$insert_row = $mysqli->query($query) or die($mysqli->error.__LINE__);
		


	$message = 'Section have been added';
	
	}
	
	
?>



<html>
<body>
	<header>

	</header>
	
<main>
	<h1> Add a section</h1>
	<?php if(isset($message)){
			echo '<p>' .$message.'</p>';

	}else {}?>
	<form method="post" action="section.php">
		<p> 
			<label> Section Name:</label>
			<input type= "text" name ="sename"/>
		</p>
		<p> 
			<label> Grade Level:</label>
			<input type= "number" name ="gradelvl" min ="0"/>
		</p>
		
		<p> 
			<label> Adviser Last Name:</label>
		<?php $query1 = "Select lname from accounts";
		$result = $mysqli->query($query1) or die($mysqli->error.__LINE__);
		?>	
		
		<select name = "adviserlname">
		<?php while ($row1 = mysqli_fetch_array($result)):;?>
		<option name = "adviserlname"><?php echo $row1[0];?></option>
		<?php endwhile;?>
		</select>
		</p>
		<p>
		<label> SchoolYear:</label>
		<?php $query2 = "Select yearid from schoolyear where scstatus = 'ACTIVE'";
		$result2 = $mysqli->query($query2) or die($mysqli->error.__LINE__);
		?>	
		
		<select name = "yearid" type = "hidden">
		<?php while ($row2 = mysqli_fetch_array($result2)):;?>
		<option name = "yearid" type = "hidden"><?php echo $row2[0];?></option>
		<?php endwhile;?>
		</select>
		

		<p>
		<input type = "submit" name = "submit" value = "submit" "0"/>
		</p>

</main>

</body>
</html>

