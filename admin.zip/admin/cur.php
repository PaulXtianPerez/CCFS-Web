<?php include 'database.php'; ?>
<?php 
	if(isset($_POST['submit'])){
		
		

		
		$query = "INSERT INTO `curriculum`(subjID, grade, yearid, ordering) values ('$_POST[subjID]', '$_POST[grade]', '$_POST[yearid]', '$_POST[ordering]')";
		
		$insert_row = $mysqli->query($query) or die($mysqli->error.__LINE__);
		


	$message = 'Curriculum have been added';
	
	}
	
	
?>



<html>
<body>
	<header>

	</header>
	
<main>
	<h1> Add a Curriculum</h1>
	<?php if(isset($message)){
			echo '<p>' .$message.'</p>';

	}else {}?>
	<form method="post" action="cur.php">
	
	
			<label> Subject :</label>
		<?php $query1 = "Select subjID from subject";
		$result = $mysqli->query($query1) or die($mysqli->error.__LINE__);
		?>	
		
		<select name = "subjID">
		<?php while ($row1 = mysqli_fetch_array($result)):;?>
		<option name = "subjID"><?php echo $row1[0];?></option>
		<?php endwhile;?>
		</select>
		</p>
		<p> 
			<label> Grade Level:</label>
			<input type= "text" name ="grade"/>
		</p>
		
		
		<p>
		<label> SchoolYear:</label>
		<?php $query2 = "Select yearid from schoolyear where scstatus = 'ACTIVE'";
		$result2 = $mysqli->query($query2) or die($mysqli->error.__LINE__);
		?>	
		
		<select name = "yearid" type = "hidden">
		<?php while ($row2 = mysqli_fetch_array($result2)):;?>
		<option name = "yearid" type = "hidden"><?php echo $row2[0];?></option>
		<?php endwhile;?>
		</select>
		
		<p> 
			<label> Grade Order:</label>
			
			<input type= "text" name ="ordering"/>
		</p>

		<p>
		<input type = "submit" name = "submit" value = "submit" "0"/>
		</p>

</main>

</body>
</html>

