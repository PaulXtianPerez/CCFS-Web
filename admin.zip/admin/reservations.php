 <?php include('../pages/server.php') ?>
 <?php  
 if(isset($_POST["reservation_id"])){  
      $id = $_POST["reservation_id"];
      $output = '';
      // Modal - Registration - Payment Info
       $query = "SELECT * FROM reservation join user using (user_id) WHERE reservation_id = ".$_POST["reservation_id"]."";
       $sth = $db->query($query);
       
       while($row = mysqli_fetch_array($sth)){  
        $output .='
            <!-- Modal Header-->
              <div class="modal-header text-center">
                <h1 class="modal-title w-100 font-weight-bold">Form Review</h1>
                <button type="button" class="close" data-dismiss="modal"><!-- Exit button-->
                </button>
              </div>

            <!-- Modal Body start -->
            <div class="modal-body">
                <form class="form-group">
                <div class = "row">
                        <div class="col-lg-6">
                            <label>First Name </label>
                            <input type="name" name="fname" class="form-control" value="'.$row["first_name"].'" readonly> <!--Change the value to (yung pag fetch database)-->
                        </div>  
                        <div class="col-lg-6">
                            <label>Last Name </label>
                            <input type="name" name="fname" class="form-control" value="'.$row["last_name"].'" readonly> <!--Change the value to (yung pag fetch database)-->
                        </div>  

                </div>

                    <div class = "row">
                        <div class="col-lg-6">
                            <label>Organization/Group/Class: </label>
                            <input type="name" name="lname" class="form-control" value="'.$row["organization"].'" readonly> <!--Change the value to (yung pag fetch database)-->
                        </div>  
                        <div class="col-lg-6">
                            <label>Adviser: </label>
                            <input type="name" name="lname" class="form-control" value="'.$row["adviser"].'" readonly> <!--Change the value to (yung pag fetch database)-->
                        </div>  
                    </div>

                    <div class = "row">
                        <div class="col-lg-6">
                            <label>Activity/Event: </label>
                            <input type="name" name="email" class="form-control" value="'.$row["activity"].'" readonly> <!--Change the value to (yung pag fetch database)-->
                        </div>  
                        <div class="col-lg-6">
                            <label>Venue: </label>
                            <input type="name" name="email" class="form-control" value="'.$row["venue"].'" readonly> <!--Change the value to (yung pag fetch database)-->
                        </div>  
                    </div>

                    <div class = "row">
                        <div class="col-lg-6">
                            <label>Date of the event: </label>
                            <input type="name" name="date" class="form-control" value="'.$row["event_date"].'" readonly> <!--Change the value to (yung pag fetch database)-->
                        </div>  
                        <div class="col-lg-6">
                            <label>Time of the event: </label>
                            <input type="name" name="time" class="form-control" value="'.$row["event_time"].'" readonly> <!--Change the value to (yung pag fetch database)-->
                        </div>  
                    </div>

                    <div class = "row">
                        <div class="col-lg-6">
                            <label>No. of members/Participant/s: </label>
                            <input type="name" name="noP" class="form-control" value="'.$row["members"].'" readonly> <!--Change the value to (yung pag fetch database)-->
                        </div>  
                        <div class="col-lg-6">
                            <label>Needed Staff:  </label>
                            <input type="name" name="noP" class="form-control" value="Security Guard" readonly> <!--Change the value to (yung pag fetch database)-->
                        </div>  
                    </div>

                    <div class = "row">
                        <div class="col-lg-6">
                            <label>Equipments: </label>
                            <input type="name" name="staff" class="form-control" value="Bench" readonly>
                            <br>
                            <input type="name" name="staff" class="form-control" value="Table" readonly> <!--Change the value to (yung pag fetch database)-->
                        </div>  
                        <div class="col-lg-6">
                            <label>Quantity:  </label>
                            <input type="name" name="Quantity" class="form-control" value="3" readonly>
                            <br>
                            <input type="name" name="Quantity" class="form-control" value="1" readonly> <!--Change the value to (yung pag fetch database)-->
                        </div>
                    </div>

                </form>

            </div>


            <div class="modal-footer d-flex justify-content-center">
                <button class="btn btn-primary"  data-toggle="modal" data-target="#modalReservation">Accept</button>
                 <button class="btn btn-primary"  data-toggle="modal" data-dismiss="modal" data-target="#modalDenied">Deny</button>
            </div>
            ';

          echo $output;
} 
}  
 ?>