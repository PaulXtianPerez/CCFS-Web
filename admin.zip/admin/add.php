<?php include 'database.php'; ?>
<?php 
	if(isset($_POST['submit'])){
		
		

		
		$query = "INSERT INTO `schoolyear`(yearstart, yearend) values ('$_POST[yearstart]', '$_POST[yearend]')";
		
		$insert_row = $mysqli->query($query) or die($mysqli->error.__LINE__);
		


	$message = 'School Year have been added';
	
	}
	
	
?>



<html>
<body>
	<header>

	</header>
	
<main>
	<h1> Add a SchoolYear</h1>
	<?php if(isset($message)){
			echo '<p>' .$message.'</p>';
	}?>
	<form method="post" action="add.php">
		<p> 
			<label> Year Start:</label>
			<input type= "number" name ="yearstart" />
		</p>
		
		<p> 
			<label> Year End:</label>
			<input type= "number" name ="yearend" />
		</p>

		<p>
		<input type = "submit" name = "submit" value = "submit" />
		</p>

</main>

</body>
</html>

