<?php include 'database.php'; ?>
<?php 
	if(isset($_POST['submit'])){
		
		

		
		$query = "INSERT INTO `subject`(subname, adviserLname, yearid) values ('$_POST[subname]', '$_POST[adviserLname]', '$_POST[yearid]')";
		
		$insert_row = $mysqli->query($query) or die($mysqli->error.__LINE__);
		


	$message = 'Subject have been added';
	
	}
	
	
?>



<html>
<body>
	<header>

	</header>
	
<main>
	<h1> Add a Subject</h1>
	<?php if(isset($message)){
			echo '<p>' .$message.'</p>';

	}else {}?>
	<form method="post" action="subj.php">
		<p> 
			<label> Subject Name:</label>
			<input type= "text" name ="subname"/>
		</p>
		
		<p> 
			<label> Adviser Last Name:</label>
		<?php $query1 = "Select lname from accounts";
		$result = $mysqli->query($query1) or die($mysqli->error.__LINE__);
		?>	
		
		<select name = "adviserLname">
		<?php while ($row1 = mysqli_fetch_array($result)):;?>
		<option name = "adviserLname"><?php echo $row1[0];?></option>
		<?php endwhile;?>
		</select>
		</p>
		<p>
		<label> SchoolYear:</label>
		<?php $query2 = "Select yearid from schoolyear where scstatus = 'ACTIVE'";
		$result2 = $mysqli->query($query2) or die($mysqli->error.__LINE__);
		?>	
		
		<select name = "yearid" type = "hidden">
		<?php while ($row2 = mysqli_fetch_array($result2)):;?>
		<option name = "yearid" type = "hidden"><?php echo $row2[0];?></option>
		<?php endwhile;?>
		</select>
		

		<p>
		<input type = "submit" name = "submit" value = "submit" "0"/>
		</p>

</main>

</body>
</html>

