<?php include 'database.php'; ?>
<?php 
	if(isset($_POST['submit'])){
		
		

		
		$query = "INSERT INTO `accounts`(empid, username, password, fname, lname, type) values ('$_POST[empid]', '$_POST[username]', '$_POST[password]', '$_POST[fname]', '$_POST[lname]', '$_POST[type]')";
		
		$insert_row = $mysqli->query($query) or die($mysqli->error.__LINE__);
		


	$message = 'Account have been added';
	
	}
	
	
?>



<html>
<body>
	<header>

	</header>
	
<main>
	<h1> Add an account</h1>
	<?php if(isset($message)){
			echo '<p>' .$message.'</p>';

	}else {}?>
	<form method="post" action="account.php">
		<p> 
			<label> Employee ID:</label>
			<input type= "text" name ="empid"/>
		</p>
		
		<p> 
			<label> USERNAME:</label>
			<input type= "text" name ="username"/>
		</p>

			<p> 
			<label> PASSWORD:</label>
			<input type= "password" name ="password"/>
		</p>

			

		<p> 
			<label> First Name:</label>
			<input type= "text" name ="fname"/>
		</p>

		<p> 
			<label> Last Name:</label>
			<input type= "text" name ="lname"/>
		</p>

		<p> 
			<label> Account Type:</label>
			<input type= "text" name ="type" />
		</p>

		

		<p>
		<input type = "submit" name = "submit" value = "submit" "0"/>
		</p>

</main>

</body>
</html>

